STATISTICS SURVEYORS AND GEOMATICS PROFESSIONALS SHOULD KNOW
Plain-Language Statistics with Worked Examples and Apps
Yam Khoon Tor, PhD, HFSISV

Copyright (c) 2026 Yam Khoon Tor. All rights reserved.
Please read COPYRIGHT.txt before using the apps.

COMPANION APPS - OFFLINE VERSION
================================

This folder contains the four interactive solvers that accompany the book.
They run in any modern web browser (Chrome, Edge, Firefox, Safari) on
Windows or Mac, with no installation and no internet connection.

HOW TO USE
1. Unzip (extract) the downloaded file to a folder on your computer.
   On Windows: right-click the zip file and choose "Extract All".
   On a Mac: double-click the zip file.
2. Open the folder and double-click START_HERE.html.
3. Choose an app. Each opens with the book's data already entered.

Keep all the files in the same folder: START_HERE.html links to the others.

THE APPS
  part1_solver.html   Part I    Measurements (Chapters 1-4)
  part2_solver.html   Part II   Computation (Chapters 5-8)
  part3_solver.html   Part III  Analysis (Chapters 9-14)
  part4_solver.html   Part IV   Reporting (Chapters 15-17) and tables
  COPYRIGHT.txt       Copyright statement and disclaimer

NOTES
- All calculations run on your own computer; no data are sent anywhere.
- Without an internet connection the apps use your computer's standard
  fonts; everything else works exactly the same.
- On tablets and phones, use the online versions linked from the book.
- The apps are for your own study and professional work only; they may
  not be copied for others or redistributed (see COPYRIGHT.txt).
